
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">

    <title>Knowledge Education Center</title>

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    
</head>

<body>
    







<footer>

        <div class="footerContainer">

            <div class="socialIcons">

                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-google-plus"></i></a>
                

            </div>

            <div class="footerNav">

                <ul>
                    <li><a href="tearm.php">Terms And Conditions</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="#">Privacy And Policy</a></li>
                </ul>
            </div>

            <div class="footerBottom">

                <p>Copyright @KnowledgeEducationCenter &copy;2024</p>
            </div>
             

        </div>


    </footer>

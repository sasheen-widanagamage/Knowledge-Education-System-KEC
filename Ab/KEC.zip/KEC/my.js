
function showPopup() {
    alert("You have successfully registered!");
}

function register() {
    // Additional logic for the register button if needed
    showPopup(); // Show the popup
}

function login() {
    // Logic for login
    alert("Login button clicked!");
}



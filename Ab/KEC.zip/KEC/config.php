<?php 


$con = new mysqli("localhost" , "root" ,"" ,"iwt");

if($con ->connect_error)
{
    die("Faile".$con ->connect_error);
}else{
    
}



?>